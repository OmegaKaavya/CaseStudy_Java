
    private double ticketPrice;